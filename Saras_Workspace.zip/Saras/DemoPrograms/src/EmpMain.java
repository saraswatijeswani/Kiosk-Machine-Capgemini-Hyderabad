import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class EmpMain {

	
	public static void main(String[] args) {
		Employee e1=new Employee(101,"Saras",10000);		
		Employee e2=new Employee(102,"Ruby",15000);
		Employee e3=new Employee(103,"Vana",20000);
		Employee e4=new Employee(104,"Pratiksha",12000);
		Employee e5=new Employee(105,"Shikha",18000);
		
		
		
		
		List<Employee> empList=new ArrayList<Employee>();
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		
		System.out.println("Before Sorting . . ");
		for(Employee e:empList){
			System.out.print(e);
		}
		

		
		
		Collections.sort(empList,new NameCompare());
		System.out.println("After Sorting . . ");
		
		for(Employee e:empList){
			System.out.print(e);
		}
		
 
	    
	}

}
