
public class MinMaxDemo {

	
	public static void main(String[] args) {
		
		int numArray[] = {10,5,20,45,25,55};
		
		
		int min=numArray[0],max=numArray[0];
		for(int i=1;i<=5;i++){
			if(max<numArray[i]){
				max=numArray[i];
				}
		}
		System.out.print("Content of Array : ");
		for(int i:numArray){
			System.out.print(i +" " );
		}
		System.out.println();
System.out.println("Maximum is : "+ max);


for(int i=1;i<=5;i++){
	if(min>numArray[i]){
		min=numArray[i];
		}
}
System.out.println("Minimum is : "+ min);
	}

}
