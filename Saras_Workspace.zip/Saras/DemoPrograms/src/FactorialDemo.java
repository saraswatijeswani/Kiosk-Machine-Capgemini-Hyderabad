import java.util.Scanner;


public class FactorialDemo {

	
	public static void main(String[] args) {
		
		System.out.println("Enter Number  : ");
		Scanner sc=new Scanner(System.in);
		
		
		int num=sc.nextInt();
		
		double fact=fact(num);
		System.out.println("Factorial is : " +fact);
		

	}

	private static double fact(int num) {
		if(num == 0)
		{
			return 1;
		
		}
		else 
			return (num* fact(num-1));
	}

}
