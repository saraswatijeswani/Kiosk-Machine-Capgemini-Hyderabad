
public class SubStringDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String myString="abcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcd";
		
		System.out.println("String of 320 characters : "+myString);
		
		String subString=myString.substring(0, 255);
		System.out.println("\nString of 256 Characters : "+subString);

	}

}
