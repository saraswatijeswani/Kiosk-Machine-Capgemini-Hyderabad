package com.cg.ems.service;


import java.util.List;

import com.cg.ems.dto.Employee;
public interface IEmpService {
	public List<Employee> getEmpList();
	public boolean authenticate(String uname,String pswd);
	public boolean addEmp(int eid,String ename,double esal);
}
