package com.cg.ems.service;

import java.util.List;



import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.IEmpDao;
import com.cg.ems.dto.Employee;

public class EmployeeService implements IEmpService{
	
	IEmpDao dao=new EmployeeDao();
	
	@Override
	public List<Employee> getEmpList() {
		
		return dao.getEmpList();
	}

	@Override
	public boolean authenticate(String uname, String pswd) {
	
		return dao.authenticate(uname, pswd);
	}

	@Override
	public boolean addEmp(int eid, String ename, double esal) {
		// TODO Auto-generated method stub
		return dao.addEmp(eid, ename, esal);
	}

}
