package com.cg.ems.controller;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.dto.Employee;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.IEmpService;

@Controller
public class EmpController {
	
	IEmpService empService=new EmployeeService();;
	
	
@RequestMapping("/authenticate")
public ModelAndView authenticate(@RequestParam String uname,@RequestParam String pswd){  
	
	if(empService.authenticate(uname, pswd))
	return new ModelAndView("Menu");
	else
	{
		String errorMsg="Wrong Credentials !! Please enter proper details ";
		return new ModelAndView("Login","errorMsg",errorMsg);
	}
}

@RequestMapping("/view")  
public ModelAndView viewemp(){  
    List<Employee> list=empService.getEmpList();  
    return new ModelAndView("EmpDetails","list",list);  
} 

@RequestMapping("/add")  
public ModelAndView showAddEmp(){
	return new ModelAndView("AddEmp");
}

@RequestMapping("/addEmp")  
public ModelAndView addemp(@RequestParam String eid,@RequestParam String ename,@RequestParam String esal){
	int empId=Integer.parseInt(eid);
	double empSal=Double.parseDouble(esal);
	empService.addEmp(empId, ename, empSal);
	List<Employee> list=empService.getEmpList();  
	return new ModelAndView("EmpDetails","list",list);    
    
}
}
