package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.dto.Employee;

public interface IEmpDao {
	public List<Employee> getEmpList();
	public boolean authenticate(String uname,String pswd);
	public boolean addEmp(int eid,String ename,double esal);
}
