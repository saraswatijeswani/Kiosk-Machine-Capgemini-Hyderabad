package com.cg.ems.dao;

import java.util.ArrayList;
import java.util.List;
import com.cg.ems.dto.Employee;

public class EmployeeDao implements IEmpDao{
	
	List<Employee> empList=new ArrayList<Employee>();
	public List<Employee> getEmpList(){
		Employee e=new Employee(101,"Saras",15000.0);
		Employee e1=new Employee(102,"Ruby",17000.0);
		Employee e2=new Employee(103,"Vandana",18000.0);
		Employee e3=new Employee(104,"Shikha",25000.0);

		
		empList.add(e);
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);

		return empList;

	}

	@Override
	public boolean authenticate(String uname, String pswd) {
		if(uname.equalsIgnoreCase("abc") && pswd.equals("abc"))
			return true;
		
		else
			return false;
	}

	@Override
	public boolean addEmp(int eid, String ename, double esal) {
		Employee e=new Employee(eid,ename,esal);
		empList.add(e);
		return true;
	}
}
