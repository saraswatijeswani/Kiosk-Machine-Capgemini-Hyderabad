package com.cg.ems.main;


import java.util.List;

import com.cg.ems.dto.Employee;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.IEmpService;

public class EmpMain {

	
	public static void main(String[] args) {
		IEmpService service=new EmployeeService();
		List<Employee> myList=service.getEmpList();
		System.out.println("EmpID"+ " EmpName "+ " EmpSalary ");
		for(Employee e:myList){
			System.out.println(e.getEmpId() + "   " + e.getEmpName() + "    " +e.getEmpSalary());
		}
	}

}
